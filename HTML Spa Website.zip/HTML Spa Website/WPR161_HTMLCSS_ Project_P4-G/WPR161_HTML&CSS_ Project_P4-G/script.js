document.addEventListener("DOMContentLoaded", function() { // Javascript code to add feature that alternates the h1 text every 5 seconds.

    const subheading = document.getElementById("Subheading"); // To link the h1 element with the id named 'Subheading'.

    let index = 0; // The index variable keeps track of the current number of the 'subheadings' array starting from 0.
    
    const subheadings = [ // Declares a constant array named 'subheadings'.
        "Wind Down and Relax", // The text that alternates in the h1 element.
        "Induldge in Tranquility",
        "Discover Harmony",
    ];

    setInterval(function() {
        subheading.textContent = subheadings[index];
        index = (index + 1) % subheadings.length;
    }, 5000);
});